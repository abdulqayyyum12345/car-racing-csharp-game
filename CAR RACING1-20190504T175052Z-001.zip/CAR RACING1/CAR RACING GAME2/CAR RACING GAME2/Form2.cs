﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace CAR_RACING_GAME2
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
            pictureBox1.Visible = false;
            pictureBox2.Visible = false;
            pictureBox3.Visible = false;      
        }
        bool drag = false;
        int mousex, mousey;
        int scor, t = 0, d = 0, can1 = 17, can2 = 36, can3 = 55, bom1 = 7, bom2 = 25, bom3 = 68, ste = 2;
        Random nr = new Random();
        private void pictureBox3_MouseUp(object sender, MouseEventArgs e)
        {
            drag = false;
        }
            
        private void Form2_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Up)
                pictureBox3.Location = new Point(pictureBox3.Location.X, pictureBox3.Location.Y - 10);
            if (e.KeyCode == Keys.Down)
                pictureBox3.Location = new Point(pictureBox3.Location.X, pictureBox3.Location.Y + 10);
            if (e.KeyCode == Keys.Left)
                pictureBox3.Location = new Point(pictureBox3.Location.X - 10, pictureBox3.Location.Y);
            if (e.KeyCode == Keys.Right)
                pictureBox3.Location = new Point(pictureBox3.Location.X + 10, pictureBox3.Location.Y);
            if (pictureBox3.Bounds.Contains(pictureBox1.Location) || pictureBox1.Bounds.Contains(pictureBox3.Location))
            {
                timer1.Enabled = false;
                timer2.Enabled = false;
                timer3.Enabled = false;
                pictureBox3.Location = new Point(120, 440);
                pictureBox1.Location = new Point(12, 27);
                pictureBox2.Location = new Point(102, 27);
                pictureBox1.Visible = false;
                pictureBox2.Visible = false;
                pictureBox3.Visible = false;
                label1.Visible = false;
                MessageBox.Show("out " + scor.ToString());
            }
            if (pictureBox3.Bounds.Contains(pictureBox2.Location) || pictureBox2.Bounds.Contains(pictureBox3.Location))
            {
                timer1.Enabled = false;
                timer2.Enabled = false;
                timer3.Enabled = false;
                pictureBox3.Location = new Point(120, 440);
                pictureBox1.Location = new Point(12, 27);
                pictureBox2.Location = new Point(102, 27);
                pictureBox1.Visible = false;
                pictureBox2.Visible = false;
                pictureBox3.Visible = false;
                label1.Visible = false;
                MessageBox.Show("end " + scor.ToString());
            }
 
           
        }

        private void Form2_Load(object sender, EventArgs e)
        {
           
        }
        private void timer1_Tick(object sender, EventArgs e)
        {

         

        }

       
        private void pictureBox3_MouseDown(object sender, MouseEventArgs e)
        {
            drag = true;
            mousex = Cursor.Position.X - pictureBox3.Left;
            mousey = Cursor.Position.Y - pictureBox3.Top;
        }

        private void pictureBox3_MouseMove(object sender, MouseEventArgs e)
        {
            if (drag == true)
                pictureBox3.Location = new Point(Cursor.Position.X - mousex, Cursor.Position.Y - mousey);
            if (pictureBox3.Location.X < 0 || pictureBox3.Location.X > 254 || pictureBox3.Location.Y < 5 || pictureBox3.Location.Y > 500)
            {
                timer1.Enabled = false;
                timer2.Enabled = false;
                timer3.Enabled = false;             
                pictureBox3.Location = new Point(120, 440);
                pictureBox1.Location = new Point(12, 27);
                pictureBox2.Location = new Point(102, 27);
                pictureBox1.Visible = false;
                pictureBox2.Visible = false;
                pictureBox3.Visible = false;
                label1.Visible = false;              
               
                MessageBox.Show("GAMEOVER" + scor.ToString());
            }
            if (pictureBox3.Bounds.Contains(pictureBox1.Location) || pictureBox1.Bounds.Contains(pictureBox3.Location))
            {
                timer1.Enabled = false;
                timer2.Enabled = false;
                timer3.Enabled = false;              
                pictureBox3.Location = new Point(120, 440);
                pictureBox1.Location = new Point(12, 27);
                pictureBox2.Location = new Point(102, 27);
                pictureBox1.Visible = false;
                pictureBox2.Visible = false;
                pictureBox3.Visible = false;
                label1.Visible = false;            
               
                MessageBox.Show("game over " + scor.ToString());
            }
            if (pictureBox3.Bounds.Contains(pictureBox2.Location) || pictureBox2.Bounds.Contains(pictureBox3.Location))
            {
                timer1.Enabled = false;
                timer2.Enabled = false;
                timer3.Enabled = false;                              
                pictureBox3.Location = new Point(120, 440);
                pictureBox1.Location = new Point(12, 27);
                pictureBox2.Location = new Point(102, 27);
                pictureBox1.Visible = false;
                pictureBox2.Visible = false;
                pictureBox3.Visible = false;
                label1.Visible = false;             
               
                MessageBox.Show("gamee over " + scor.ToString());
            }
        
        }

        private void newGameToolStripMenuItem_Click(object sender, EventArgs e)
        {
            timer1.Enabled = true;
            timer2.Enabled = true;
            timer3.Enabled = true;
            pictureBox1.Visible = true;
            pictureBox2.Visible = true;
            pictureBox3.Visible = true;
            label1.Visible = true;
            pictureBox1.Location = new Point(0, 27);
            pictureBox2.Location = new Point(202, 287);
            pictureBox3.Location = new Point(120, 440);
            scor = 0;
            d = 0;
            t = 0;

            drag = false;
        }

        private void timer1_Tick_1(object sender, EventArgs e)
        {
            pictureBox1.Location = new Point(pictureBox1.Location.X, pictureBox1.Location.Y + 5);
            int n = nr.Next(1, 4);
            if (pictureBox1.Location.Y > 480 && n == 1)
            {
                pictureBox1.Location = new Point(12, 0);
            }
            if (pictureBox1.Location.Y > 480 && n == 2)
            {
                pictureBox1.Location = new Point(102, 0);
            }
            if (pictureBox1.Location.Y > 480 && n == 3)
            {
                pictureBox1.Location = new Point(192, 0);
            }
        }

        private void timer2_Tick(object sender, EventArgs e)
        {
            Random mr = new Random();
            pictureBox2.Location = new Point(pictureBox2.Location.X, pictureBox2.Location.Y + 5);
            int m = mr.Next(1, 4);
            if (pictureBox2.Location.Y > 480 && m == 1)
            {
                pictureBox2.Location = new Point(12, 0);
            }
            if (pictureBox2.Location.Y > 480 && m == 2)
            {
                pictureBox2.Location = new Point(102, 0);
            }
            if (pictureBox2.Location.Y > 480 && m == 3)
            {
                pictureBox2.Location = new Point(192, 0);
            }
        }

        private void timer3_Tick(object sender, EventArgs e)
        {
            scor = scor + 1;
            label1.Text = "SCORE: " + scor.ToString();
            if (pictureBox3.Bounds.Contains(pictureBox1.Location) || pictureBox1.Bounds.Contains(pictureBox3.Location))
            {
                timer1.Enabled = false;
                timer2.Enabled = false;
                timer3.Enabled = false;
                pictureBox3.Location = new Point(120, 440);
                pictureBox1.Location = new Point(12, 27);
                pictureBox2.Location = new Point(102, 27);
                pictureBox1.Visible = false;
                pictureBox2.Visible = false;
                pictureBox3.Visible = false;
                label1.Visible = false;
                MessageBox.Show("start" + scor.ToString());
            }
            if (pictureBox3.Bounds.Contains(pictureBox2.Location) || pictureBox2.Bounds.Contains(pictureBox3.Location))
            {
                timer1.Enabled = false;
                timer2.Enabled = false;
                timer3.Enabled = false;
                pictureBox3.Location = new Point(120, 440);
                pictureBox1.Location = new Point(12, 27);
                pictureBox2.Location = new Point(102, 27);
                pictureBox1.Visible = false;
                pictureBox2.Visible = false;
                pictureBox3.Visible = false;
                label1.Visible = false;
                MessageBox.Show("destroy " + scor.ToString());
            }

        }





    }
}
